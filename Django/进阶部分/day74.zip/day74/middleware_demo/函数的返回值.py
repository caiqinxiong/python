def foo():
    return



ret = foo()
print(ret)
