# -*- coding:utf-8 -*-
# Author:caiqinxiong

# 信用卡使用额度
limit = 15000