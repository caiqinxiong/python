# -*- coding:utf-8 -*-
# Author:caiqinxion
#import os,sys
#BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
#sys.path.append(BASE_DIR)
#print(BASE_DIR)
from login import LOGIN

def main():
    LOGIN.login('name')


if __name__ == '__main__':
    main()